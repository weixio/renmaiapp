//num
define([], function () {
     return 10;
});